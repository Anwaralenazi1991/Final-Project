package com.app1

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RestaurantsActivity : AppCompatActivity() {

    lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.restaurants_acitvity)

        listView = findViewById(R.id.myListView)

        val list = mutableListOf<Model>()
        list.add(Model("McDonald's", "Al-malqa branch", R.drawable.mcdonalds_icon))
        list.add(Model("Herfy", "Al-narjis branch", R.drawable.herfy_icon))
        list.add(Model("Kfc", "Al-yasmin branch", R.drawable.kfc_iconic))
        list.add(Model("Pizza hut", "Al-yasmin branch", R.drawable.hut_iconic))
        list.add(Model("Burger King", "Al-yasmin branch", R.drawable.king_logo))
        list.add(Model("Kudu", "Al-yasmin branch", R.drawable.kudu_logo))




        listView.adapter = MyListAdapter(this, R.layout.row, list)

        listView.setOnItemClickListener { _, _, id, _ ->
            val toRestaurantMenuActivity = Intent(this, RestaurantMenu::class.java)
            toRestaurantMenuActivity.putExtra("menu_id", id.toString())
            startActivity(toRestaurantMenuActivity)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_cart -> {
                val toCartActivity = Intent(this, CartActivity::class.java)
                startActivity(toCartActivity)
                true
            }
            R.id.action_settings -> {
                val toSettingActivity = Intent(this, SettingActivity::class.java)
                startActivity(toSettingActivity)
                true
            }
            R.id.action_logout -> {
                Toast.makeText(applicationContext, "You Logged Out", Toast.LENGTH_LONG).show()
                val toLoginActivity = Intent(this, MainActivity::class.java)
                startActivity(toLoginActivity)
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
