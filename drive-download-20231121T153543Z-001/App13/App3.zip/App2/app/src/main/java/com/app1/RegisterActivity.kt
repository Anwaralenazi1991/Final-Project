package com.app1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {

    lateinit var loginButton: TextView
    lateinit var registerButton: Button
    lateinit var username: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register_acitivty)

        loginButton = findViewById(R.id.login_reg_page)
        registerButton = findViewById(R.id.register_button_reg_page)
        username = findViewById(R.id.username_value)

        loginButton.setOnClickListener {
            val toLoginActivity = Intent(this, MainActivity::class.java)
            startActivity(toLoginActivity)
        }

        registerButton.setOnClickListener {
            if (username .text.isEmpty()) {
                Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show()

            } else {
                Toast.makeText(
                    this,
                    "Welcome " + username.text.toString() + " , please Login",
                    Toast.LENGTH_SHORT
                )
                    .show()
            }
        }


    }
}
