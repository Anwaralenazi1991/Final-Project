package com.app1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class RestaurantMenu : AppCompatActivity() {

    lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.restaurant_menu)

        val menuId: String = intent.getStringExtra("menu_id")!!
        Log.d("test000121", menuId)

        listView = findViewById(R.id.myListViewMenu)

        val list = mutableListOf<MenuModel>()

        when (menuId) {
            "0" -> {
                list.add(MenuModel("Chicken Burger", "16$", R.drawable.mac_burger_1))
                list.add(MenuModel("Diet Chicken Burger", "22$", R.drawable.mac_burger_2))
                list.add(MenuModel("Double Burger with Cheese", "25$", R.drawable.mac_burger_3))
                list.add(MenuModel("Burger with Cheese", "20$", R.drawable.mac_burger_4))
            }
            "1" -> {
                list.add(MenuModel("Chicken Burger", "15$", R.drawable.herfy_menu_1))
                list.add(MenuModel("Kids meal", "10$", R.drawable.herfy_menu_2))
                list.add(MenuModel("Chicken Burger with Cheese", "25$", R.drawable.herfy_menu_3))
                list.add(MenuModel("Fish", "20$", R.drawable.herfy_menu_4))
                list.add(MenuModel("Big Chicken With Cheese", "30$", R.drawable.herfy_menu_5))
                list.add(MenuModel("Tortilla Chicken", "20$", R.drawable.herfy_menu_6))
                list.add(MenuModel("Salade", "13$", R.drawable.herfy_menu_7))
            }
            "2" -> {
                list.add(MenuModel("Chicken Burger", "15$", R.drawable.kfc_bur))
                list.add(MenuModel("Box Chicken", "20$", R.drawable.kfc_box))
                list.add(MenuModel("twister", "16$", R.drawable.kfc_twis))
                list.add(MenuModel("Pepsi", "1$", R.drawable.pep))
                list.add(MenuModel("7Up", "1$", R.drawable.up))
                list.add(MenuModel("Water", "1$", R.drawable.water))
            }
            "3" -> {
                list.add(MenuModel("Marguerita", "15$", R.drawable.marguerita01))
                list.add(MenuModel("tropical hawaiian", "15$", R.drawable.pwahawaian))
                list.add(MenuModel("Pepperoni", "15$", R.drawable.pepperoni01))
                list.add(MenuModel("Cheesy Pops", "20$", R.drawable.cheesy_zft))
                list.add(MenuModel("Chicken Bites", "25$", R.drawable.cheesy_pops01))
                list.add(MenuModel("Pepsi", "1$", R.drawable.pep))
                list.add(MenuModel("7Up", "1$", R.drawable.up))
                list.add(MenuModel("Water", "1$", R.drawable.water))
            }
            "4" -> {
                list.add(MenuModel("Fish Royal", "24$", R.drawable.king_fishroyal))
                list.add(MenuModel("Spicy Chicken", "25$", R.drawable.king_spicychken))
                list.add(MenuModel("Meet Whoober", "26$", R.drawable.king_whoober))
                list.add(MenuModel("Frires", "10$", R.drawable.king_fries))
                list.add(MenuModel("Pepsi", "1$", R.drawable.pep))
                list.add(MenuModel("7Up", "1$", R.drawable.up))
                list.add(MenuModel("Water", "1$", R.drawable.water))
            }
            "5" -> {
                list.add(MenuModel("Beef Combo", "25$", R.drawable.kudu_beef_combo))
                list.add(MenuModel("Chicken Combo", "23$", R.drawable.kudu_chicken_combo))
                list.add(MenuModel("Lafino Chicken", "20$", R.drawable.kudu_lafino_chicken))
                list.add(MenuModel("Pepsi", "1$", R.drawable.pep))
                list.add(MenuModel("7Up", "1$", R.drawable.up))
                list.add(MenuModel("Water", "1$", R.drawable.water))
            }
        }

        listView.adapter = MyMenuListAdapter(this, R.layout.menu_row, list)

        listView.setOnItemClickListener { _, _, position, id ->
            Log.d("test0000", position.toString())
            Log.d("test00001", id.toString())
        }


    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_cart -> {
                val toCartActivity = Intent(this, CartActivity::class.java)
                startActivity(toCartActivity)
                true
            }
            R.id.action_settings -> {
                val toSettingActivity = Intent(this, SettingActivity::class.java)
                startActivity(toSettingActivity)
                true
            }
            R.id.action_logout -> {
                Toast.makeText(applicationContext, "You Logged Out", Toast.LENGTH_LONG).show()
                val toLoginActivity = Intent(this, MainActivity::class.java)
                startActivity(toLoginActivity)
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
