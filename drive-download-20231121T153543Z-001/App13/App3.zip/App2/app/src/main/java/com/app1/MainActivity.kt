package com.app1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    lateinit var loginButton: Button
    lateinit var registerButton: TextView
    lateinit var username: EditText
    lateinit var forgetText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        loginButton = findViewById(R.id.login_button)
        registerButton = findViewById(R.id.register_button)
        username = findViewById(R.id.username_value_login_page)
        forgetText = findViewById(R.id.textView2)

        forgetText.setOnClickListener {
            val toForgetPasswordActivity = Intent(this, ForgetAcitivty::class.java)
            startActivity(toForgetPasswordActivity)
        }

        loginButton.setOnClickListener {
            if (username.text.isNotEmpty()) {
                Toast.makeText(this, "Welcome back " + username.text.toString(), Toast.LENGTH_SHORT)
                    .show()
                val toRestaurantsActivity = Intent(this, RestaurantsActivity::class.java)
                startActivity(toRestaurantsActivity)
            } else {
                Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show()
            }
        }

        registerButton.setOnClickListener {
            val toRegisterActivity = Intent(this, RegisterActivity::class.java)
            startActivity(toRegisterActivity)
        }

    }


}
