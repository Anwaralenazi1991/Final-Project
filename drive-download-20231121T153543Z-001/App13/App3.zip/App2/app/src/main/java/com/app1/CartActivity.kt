package com.app1

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.app1.db.MindOrksDBOpenHelper


class CartActivity : AppCompatActivity() {

    lateinit var itemsOnCart: TextView
    lateinit var itemsOnCartPrice: TextView
    lateinit var cartEmpty: TextView
    lateinit var checkoutButton: Button
    lateinit var deleteButton: TextView

    var totalAmount = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cart_activity)

        itemsOnCart = findViewById(R.id.cartListTextView)
        itemsOnCartPrice = findViewById(R.id.cartListPriceTextView)
        cartEmpty = findViewById(R.id.cartEmpty)
        checkoutButton = findViewById(R.id.checkout_button)
        deleteButton = findViewById(R.id.textView8)

        checkoutButton.setOnClickListener {
            val toCheckoutActivity = Intent(this, CheckoutActivity::class.java)
            toCheckoutActivity.putExtra("total_amount", totalAmount.toString())
            startActivity(toCheckoutActivity)
        }

        deleteButton.setOnClickListener {
            Toast.makeText(this, "Your cart is clean", Toast.LENGTH_SHORT).show()
            val dbHandler = MindOrksDBOpenHelper(this, null)
            val cursor = dbHandler.deleteAllItems()
            cursor!!.moveToFirst()
            cursor.close()
            onBackPressed()
        }

        val dbHandler = MindOrksDBOpenHelper(this, null)
        val cursor = dbHandler.getAllItems()
        cursor!!.moveToFirst()

        if (cursor.count > 0) {
            cartEmpty.visibility = View.GONE
            deleteButton.visibility = View.VISIBLE
            checkoutButton.visibility = View.VISIBLE

            itemsOnCart.append((cursor.getString(cursor.getColumnIndex(MindOrksDBOpenHelper.COLUMN_NAME))))
            itemsOnCartPrice.append((cursor.getString(cursor.getColumnIndex(MindOrksDBOpenHelper.COLUMN_PRICE))))

            val firstDigit =
                cursor.getString(cursor.getColumnIndex(MindOrksDBOpenHelper.COLUMN_PRICE))
                    .toString().replace("$", "SR").toInt()

            while (cursor.moveToNext()) {
                itemsOnCart.append("\n")
                itemsOnCart.append("\n")
                itemsOnCart.append((cursor.getString(cursor.getColumnIndex(MindOrksDBOpenHelper.COLUMN_NAME))))

                itemsOnCartPrice.append("\n")
                itemsOnCartPrice.append("\n")
                itemsOnCartPrice.append((cursor.getString(cursor.getColumnIndex(MindOrksDBOpenHelper.COLUMN_PRICE))))


                totalAmount += cursor.getString(cursor.getColumnIndex(MindOrksDBOpenHelper.COLUMN_PRICE)).toString().replace(
                    "$",
                    "SR"
                ).toIntOrNull()!!
            }
            cursor.close()

            totalAmount += firstDigit

        } else {
            cartEmpty.visibility = View.VISIBLE
            deleteButton.visibility = View.VISIBLE
            checkoutButton.visibility = View.VISIBLE
        }
    }
}