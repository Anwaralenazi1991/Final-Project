package com.app1

import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CheckoutActivity : AppCompatActivity() {

    lateinit var totalAmountTV: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.checkout_activity)

        val totalAmount: String = intent.getStringExtra("total_amount")!!
        totalAmountTV = findViewById(R.id.textView6)
        totalAmountTV.text = "Total Amount to pay: $totalAmount SAR"
    }
}