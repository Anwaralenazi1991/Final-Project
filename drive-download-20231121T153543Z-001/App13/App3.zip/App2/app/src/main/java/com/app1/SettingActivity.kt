package com.app1

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity


@SuppressLint("Settings")
class SettingActivity: AppCompatActivity() {

    lateinit var saveButton: Button
    lateinit var cancelButton: Button
    lateinit var username: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.setting_activity)

        this.saveButton = findViewById(R.id.action_settings)
        this.cancelButton = findViewById(R.id.action_settings)
        this.username = findViewById(R.id.username_value)

        saveButton.setOnClickListener {
            val toSettingActivity = Intent(this, SettingActivity::class.java)
            startActivity(toSettingActivity)
        }
        if (username.text.isEmpty()) {
            Toast.makeText(this, "Please enter a username", Toast.LENGTH_SHORT).show()

                    } else {
                        Toast.makeText(
                            this,
                            "Welcome " + username.text.toString() + " , please Login",
                            Toast.LENGTH_SHORT
                        )
                            .show()

                        cancelButton.setOnClickListener {
                            val toSettingActivity = Intent(this, SettingActivity::class.java)
                            startActivity(toSettingActivity)

                        }
                    }
                }
            }




